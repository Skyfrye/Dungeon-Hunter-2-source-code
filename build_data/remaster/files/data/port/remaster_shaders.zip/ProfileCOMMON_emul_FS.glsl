#ifdef GL_ES
#extension GL_OES_standard_derivatives : enable
#endif
#ifdef GL_FRAGMENT_PRECISION_HIGH
	// define maxp based on user preference
	#ifdef GLITCH_USE_HIGHP
		#define MAXP highp
	#else
		#define MAXP mediump
	#endif
#else
	// force maxp as medium
	#define MAXP mediump

	// don't use bias, even if the user specify it, unless he/she explicitly force it
	#ifdef GLITCH_FORCE_USE_BIAS
		#ifndef GLITCH_USE_BIAS
			#define GLITCH_USE_BIAS
		#endif
	#else
		#ifdef GLITCH_USE_BIAS
			#undef GLITCH_USE_BIAS
		#endif
	#endif
#endif

#ifdef GLITCH_USE_BIAS
	#define TEXTURE2D(sampler, coord, bias) texture2D(sampler, coord, bias)
#else
	#define TEXTURE2D(sampler, coord, bias) texture2D(sampler, coord)
#endif

#ifdef TEXTURED
uniform lowp sampler2D Sampler0;
varying MAXP vec2 vTexCoord0;
uniform mediump float sampler0_bias;
#endif
#ifdef MULTITEXTURED
uniform lowp sampler2D Sampler1;
varying MAXP vec2 vTexCoord1;
uniform lowp float envmapIntensity;
uniform mediump float sampler1_bias;
#endif //MULTITEXTURED
#ifdef LIGHTMAP
varying MAXP vec2 vTexCoord2;
uniform lowp sampler2D Sampler2;
uniform mediump float sampler2_bias;
#endif

#ifdef FOG
uniform lowp vec4 fogcolor;
varying lowp float fogFactor;
#endif //FOG

varying lowp vec4 vColor0;
#if defined LIGHTING && defined TEXTURED
// DH2 remaster (tools/trackb/remaster_shaders.py)
varying highp vec3 vNmWorldPos;
varying mediump vec3 vNmWorldNormal;
varying mediump vec3 vNmLightVec;
varying mediump vec3 vNmEyeVec;
uniform lowp sampler2D NormalSampler;
uniform mediump float NormalStrength;
uniform mediump float NormalGreen;
uniform mediump float PixelLighting;
uniform mediump float SpecularBoost;
uniform mediump float RimStrength;
uniform highp vec3 Light0Attenuation;
uniform highp vec4 Light0Ambientcolor;
uniform highp vec4 Light0Diffusecolor;
uniform highp vec4 Light0Specularcolor;
uniform highp vec4 emissioncolor;
uniform highp vec4 ambientcolor;
uniform highp vec4 specularcolor;
uniform highp float shininess;
uniform highp vec4 SceneAmbientLight;
uniform mediump vec4 DiffuseColor;
// dynamic lights (torches, spells; game-app remaster_lights.cpp): position, colour with intensity in alpha, radius in x
uniform highp vec4 Light5Position;
uniform mediump vec4 Light5Diffusecolor;
uniform highp vec3 Light5Attenuation;
uniform highp vec4 Light6Position;
uniform mediump vec4 Light6Diffusecolor;
uniform highp vec3 Light6Attenuation;
uniform highp vec4 Light7Position;
uniform mediump vec4 Light7Diffusecolor;
uniform highp vec3 Light7Attenuation;
mediump vec3 dhPointLight(highp vec3 p, mediump vec4 c, highp float r, mediump vec3 n)
{
	highp vec3 v = p - vNmWorldPos;
	highp float d2 = dot(v, v);
	mediump float w = clamp(1.0 - d2 / max(r * r, 1.0), 0.0, 1.0);
	w *= w;
	return c.rgb * (c.a * w * max(dot(n, v * inversesqrt(max(d2, 1.0))), 0.0));
}
#endif

uniform mediump float AlphaCoverage;

uniform lowp float AlphaRef;

void main()
{
	lowp vec4 color = vColor0;
#if defined LIGHTING && defined TEXTURED
	// DH2 remaster: normal map, per-pixel lighting (the original's formula), view-dependent specular, rim light
	mediump vec3 dhN = normalize(vNmWorldNormal);
	mediump vec3 dhNp = dhN;
	if (NormalStrength > 0.0)
	{
		mediump vec3 nm = texture2D(NormalSampler, vTexCoord0).xyz * 2.0 - 1.0;
		nm.y *= (NormalGreen < 0.0) ? -1.0 : 1.0;
		highp vec3 dp1 = dFdx(vNmWorldPos);
		highp vec3 dp2 = dFdy(vNmWorldPos);
		highp vec2 duv1 = dFdx(vTexCoord0);
		highp vec2 duv2 = dFdy(vTexCoord0);
		highp vec3 dp2perp = cross(dp2, dhN);
		highp vec3 dp1perp = cross(dhN, dp1);
		highp vec3 T = dp2perp * duv1.x + dp1perp * duv2.x;
		highp vec3 B = dp2perp * duv1.y + dp1perp * duv2.y;
		// unit axes in the surface plane: each triangle's frame then differs from its neighbour's only by a small rotation.
		// (Scaling both by the longer axis, the usual cotangent frame, changed the bump strength from triangle to triangle
		// where the floor's mapping is stretched unevenly: visible lines along the triangle edges.)
		T = T - dhN * dot(dhN, T);
		B = B - dhN * dot(dhN, B);
		T *= inversesqrt(max(dot(T, T), 1e-12));
		B *= inversesqrt(max(dot(B, B), 1e-12));
		dhNp = normalize(T * nm.x + B * nm.y + dhN * nm.z);
	}
	highp float dhDist = length(vNmLightVec);
	mediump vec3 dhL = vNmLightVec / max(dhDist, 1e-4);
	mediump vec3 dhV = normalize(vNmEyeVec);
	mediump float dhAtt = 1.0 / (Light0Attenuation.x + Light0Attenuation.y * dhDist + Light0Attenuation.z * dhDist * dhDist);
	if (PixelLighting > 0.0)
	{
		// the original's vertex shader uses the world normal without normalising it: its length is kept in N.L
		// wrapped diffuse: the player's light sits just above the characters, so with plain N.L only their tops caught it and they
		// stayed dark next to the lit floor; wrapping lets it reach their sides
		mediump float nDotVP = max((dot(dhNp, dhL) + 0.6) / 1.6, 0.0) * length(vNmWorldNormal);
		mediump float nDotHV = max(dot(dhNp, normalize(dhL + dhV)), 0.0);
		mediump float pf = nDotVP > 0.0 ? pow(nDotHV, max(shininess, 0.0001)) : 0.0;
		highp vec4 lit = emissioncolor + (SceneAmbientLight + Light0Ambientcolor * dhAtt) * ambientcolor
		               + Light0Diffusecolor * (nDotVP * dhAtt) * DiffuseColor
		               + Light0Specularcolor * (pf * dhAtt * SpecularBoost) * specularcolor;
		color = vec4(clamp(lit.xyz, 0.0, 1.0), vColor0.w);
	}
	if (RimStrength > 0.0)
	{
		mediump float rim = 1.0 - max(dot(dhNp, dhV), 0.0);
		color.xyz += (rim * rim * rim * RimStrength) * clamp(Light0Diffusecolor.xyz * (0.5 + dhAtt), 0.0, 1.0);
	}
	// dynamic lights (torches, spells), before the texture is applied
	color.xyz += (dhPointLight(Light5Position.xyz, Light5Diffusecolor, Light5Attenuation.x, dhNp)
	            + dhPointLight(Light6Position.xyz, Light6Diffusecolor, Light6Attenuation.x, dhNp)
	            + dhPointLight(Light7Position.xyz, Light7Diffusecolor, Light7Attenuation.x, dhNp)) * DiffuseColor.xyz;
#endif

#ifdef TEXTURED
	color *= TEXTURE2D(Sampler0, vTexCoord0, sampler0_bias);
#endif
#ifdef LIGHTMAP
	color *= TEXTURE2D(Sampler2, vTexCoord2, sampler2_bias);
#endif


#if defined LIGHTING && defined TEXTURED
	if (NormalStrength > 0.0)
	{
		// detail relief against Light0 tipped towards an oblique direction (world is Z-up)
		mediump vec3 dhRL = normalize(dhL + vec3(-0.55, 0.55, 0.35));
		mediump float relief = 1.0 + NormalStrength * (dot(dhNp, dhRL) - dot(dhN, dhRL));
		color.xyz *= clamp(relief, 0.5, 1.5);
	}
#endif
#ifdef ALPHATEST
	if (AlphaCoverage > 0.0)
	{
		// DH2 remaster: alpha to coverage - the cut becomes a one-pixel ramp that MSAA turns into partial coverage
		color.a = clamp((color.a - AlphaRef) / max(fwidth(color.a), 1e-3) + 0.5, 0.0, 1.0);
		if (color.a <= 0.0) discard;
	}
	else if (color.a <= AlphaRef)
	{
		discard;
	}
#endif

#ifdef MULTITEXTURED
	color.rgb += TEXTURE2D(Sampler1, vTexCoord1, sampler1_bias).rgb * envmapIntensity;
#endif //MULTITEXTURED	

#ifdef FOG
    color.xyz = mix(color.xyz, fogcolor.xyz, fogFactor);
#ifdef ADDITIVEBLEND
    color.xyz *= (1.0 - fogFactor);
#endif	
#endif //FOG
	gl_FragColor = color;
}
